
package com.mycompany.keke;

import java.util.Scanner;

public class MedinaLiamFechaMain {

    public static void main(String[] args) {
        //creo las variables donde se guardaran los dias que nos introduzca el usuario y ademas con las que enviaremos la infromacion al contructor
        //tambien creo la variable de la respuesta del usuario aunque no es necesario crearla aqui
        int dia = 0;
        int mes = 0;
        int año = 0;
        int respuesta = 0;
        //creo el scanner para empezar a pedir la fecha al usuario
        Scanner entrada = new Scanner (System.in);
        boolean salida = false;
        //pido el dia y hago una validacion de dato simple
        System.out.println("Introduce el dia en el que estamos hoy");
        while (!salida){
            if (entrada.hasNextInt()){
                dia = entrada.nextInt();
                salida = true;
            } else {
                System.out.println("Este no es un dia valido, introduce el dia de nuevo");
            }
            entrada.nextLine();
        }
        //a continuacion pido el mes y vuelvo a hacer una validacion de dato
        boolean salida2 = false;
        System.out.println("Introduce el mes en el que estamos hoy");
        while (!salida2){
            if (entrada.hasNextInt()){
                mes = entrada.nextInt();
                salida2 = true;
            } else {
                System.out.println("Este no es un mes valido, introduce el dia de nuevo");
            }
        }
        //po ultimo repito lo mismo con el año
        boolean salida3 = false;
        System.out.println("Introduce el año en el que estamos hoy");
        while (!salida3){
            if (entrada.hasNextInt()){
                año = entrada.nextInt();
                salida3 = true;
            } else {
                System.out.println("Este no es un año valido, introduce el dia de nuevo");
            }
        }
        //envio la informacion al constructor de la otra clase
        MedinaLiamFecha p1 = new MedinaLiamFecha(dia, mes, año);
        //calculo si el año introducido es bisiesto
        p1.añoBisiesto();
        //imprimo la informacion que me acaba de dar el usuario
        p1.Informacion();
        System.out.println("");
        
        //por ultimo hago un bucle donde el usuario puede estar sumando dias infinitamente hasta que se canse y quiera salir del programa
        do{
            entrada.nextLine();
            //le informo de como se suma un dia y como se sale del programa
            System.out.println("¿Quieres sumar un dia a la fehca actual?");
            System.out.println("");
            System.out.println("[1] = Si");
            System.out.println("[2] = Salir del programa");
            //hago una validacion de dato antes de introducir la respuesta a la variable
            if (entrada.hasNextInt()){
                respuesta = entrada.nextInt();
            } else {
                System.out.println("Error");
            }
            //por ultimo si el usuario ha decidido sumar un dia lo sumo con la clase de sumar dia, calculo el año bisiesto otra vez por si se ha pasado de año
            //y devuelvo la informacion actualizada
            if (respuesta == 1){
                p1.SumarDia();
                p1.añoBisiesto();
                p1.Informacion();
            }
        }while(respuesta != 2);
        
    }
    
}
