package com.mycompany.keke;

public class MedinaLiamFecha {
    
    //creo las variables para la fecha completa y ademas creo uno para saber si el año es bisiesto o no

    int dia;
    int mes;
    int año;
    boolean bisiesto;
    
    //hago un contructor para añadir la informacion que nos ha proporcionado el usuario
    public MedinaLiamFecha(int dia, int mes, int año) {
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }
    
    //aqui hago la operacion simple para saber si el año es bisiesto o no (me he equivocado ya que no tiene que dar 0, sino que tiene que dar un entero pero no me da tiempo a corregirlo)
    public void añoBisiesto() {
        int resultado = año%100;
        int resultado2 = año%400;
        
        if (resultado == 0){
            if(resultado2 == 0){
                bisiesto = true;
            } else {
                bisiesto = false;
            }
        } else {
            bisiesto = false;
        }
    }
    
    //aqui hago la operacion para sumar el dia a la fecha, se podria haber hecho con un switch pero para mi en este caso era mas sencillo de esta forma
    public void SumarDia() {
        if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
            if (dia < 31) {
                dia++;
            } else {
                mes++;
                dia = 01;
            }
        } else if (mes == 2) {
            if (bisiesto == true) {
                if (dia < 28) {
                    dia++;
                } else {
                    mes++;
                    dia = 01;
                }
            } else {
                if (dia < 27) {
                    dia++;
                } else {
                    mes++;
                    dia = 01;
                }
            }
        } else {
            if (dia < 30) {
                dia++;
            } else {
                mes++;
                dia = 01;
            }
        }
    }
    //por ultimo creo la calse para poder devolver la informacion de la fecha al usuario y ademas se el año es bisesto o no
    public void Informacion (){
        System.out.println("La fecha del dia de hoy es: " + dia + "/" + mes + "/" + año);
        if (bisiesto == true){
            System.out.println("Este año es bisiesto");
        } else {
            System.out.println("Este año no es bisiesto");
        }
    }

}
