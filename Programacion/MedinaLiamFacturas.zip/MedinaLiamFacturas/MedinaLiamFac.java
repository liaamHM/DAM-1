
package com.mycompany.keke2;

public class MedinaLiamFac {
    //creo los atribuos necesarios y obligatorios
    String item;
    int cantidad;
    float precio;
    //hago un setter porque del usuario solo necesit saber la cantidad que quiere
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    //hago un constructor vacio para poder inicializar la clase
    public MedinaLiamFac() {
    }

    //hago la operacion del IVA con el precio final de lo que quiere el usuario
    public float sumaIVA(float precio){
        float iva = 21*precio/100;
        float resultado = precio + iva;
        return resultado;
    }
    //aqui creo varios items para que el usuario pueda decidir
    //en cada uno primero establezco el precio que tendra
    //segundo calculo el precio SIN IVA con la cantidad que me ha introducido el usuario
    //ahora sumo el IVA utilizando al funcion que he creado antes para sumar el IVA
    //por ultimo devuelvo el precio final
    public float Pan(){
        float precioPan = 1;
        item = "Barra de pan";
        precio = precioPan * cantidad;
        float precioFin = (float) sumaIVA(precio);
        return precioFin;
    }
    public float Magdalena(){
        float precioMag = (float) 1.50;
        item = "Magdalena";
        precio = precioMag * cantidad;
        float precioFin = (float) sumaIVA(precio);
        return precioFin;
    }
    public float Croissant(){
        float precioCroi = (float) 1.50;
        item = "Croissant";
        precio = precioCroi * cantidad;
        float precioFin = (float) sumaIVA(precio);
        return precioFin;
    }
    public float CroissantChoc(){
        float precioCroiC = (float) 1.70;
        item = "Croissant de Chocolate";
        precio = precioCroiC * cantidad;
        float precioFin = (float) sumaIVA(precio);
        return precioFin;
    }
}
