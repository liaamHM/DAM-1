
package com.mycompany.keke2;

import java.util.Scanner;

public class MedinaLiamFacMain {

    public static void main(String[] args) {
        //creo las uncias variables necesarias en la main
        int respuesta = 0;
        int cantidad = 0;
        //creo un bucle para saber que quiere comprar el usuario
        do{
            //le pregunto al usuario que quiere comprar
            Scanner entrada = new Scanner (System.in);
            System.out.println("");
            System.out.println("¿Que articluo quieres comprar?");
            System.out.println("");
            System.out.println("[1] Una barra de pan");
            System.out.println("[2] Una Magdalena");
            System.out.println("[3] Un croissant");
            System.out.println("[4] Un corissant de chocolate");
            System.out.println("[5] Salir del programa");
            //valido el dato de la respuesta
            boolean salir= false;
            while(!salir){
                if (entrada.hasNextInt()){
                    respuesta = entrada.nextInt();
                    if (respuesta <=5){
                        salir = true;
                    }else{
                        System.out.println("Error, introduce un numero valido");
                    }
                } else {
                    System.out.println("Introduce un numero entero");
                }
                entrada.nextLine();
            }
            //ahora le pregunto al usuario la cantidad de cosas que quiere comprar
            System.out.println("¿Cuantos quieres comprar?");
            //valido tambien esta respuesta
            boolean salir2= false;
            while(!salir2){
                if (entrada.hasNextInt()){
                    cantidad = entrada.nextInt();
                    salir2 = true;
                } else {
                    System.out.println("Introduce un numero entero");
                }
                entrada.nextLine();
            }
            //inicializo la otra clase
            MedinaLiamFac p1 = new MedinaLiamFac();
            //introduzco la cantidad
            p1.setCantidad(cantidad);
            //hago un switch para saber que cosa me ha pedido y hacerle la factura individual de ese item
            switch (respuesta) {
                case 1:
                    System.out.println("Has comprado " + cantidad + " barra/s de pan");
                    System.out.println("Precio: " + p1.Pan());
                    break;
                case 2:
                    System.out.println("Has comprado " + cantidad + " magdalena/s");
                    System.out.println("Precio: " + p1.Magdalena());
                    break;
                case 3:
                    System.out.println("Has comprado " + cantidad + " croissant/s");
                    System.out.println("Precio: " + p1.Croissant());
                    break;
                case 4:
                    System.out.println("Has comprado " + cantidad + " croissant/s de chocolate");
                    System.out.println("Precio: " + p1.CroissantChoc());
                    break;
                default:
                    break;
            }
        }while (respuesta != 5);
    }
    //pese a que no lo he hecho la forma de hacer la factura con varios items es con un arraylist, primero pides al usuario varios items con su respectiva cantidad
    //y despues por otro parte haces los calculos del arraylist y los imprimes en una sola factura
    
}
