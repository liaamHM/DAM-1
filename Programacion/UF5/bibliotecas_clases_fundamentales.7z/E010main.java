package dev.boca.uf5.bibliotecas_clases_fundamentales;
public class E010main {
    public static void main(String[] args) {
        E010cajaTexto ejemplo = new E010cajaTexto("Elementos de texto");
        ejemplo.setVisible(true);
    }
    
}
