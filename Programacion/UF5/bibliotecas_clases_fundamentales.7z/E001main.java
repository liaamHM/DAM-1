package dev.boca.uf5.bibliotecas_clases_fundamentales;
public class E001main {
    public static void main(String[] args) {
        E001ventana ventana = new E001ventana();

        ventana.setVisible(true);
    }
    
}
