package dev.boca.uf5.bibliotecas_clases_fundamentales;
public class E013main {
    public static void main(String[] args) {
        E013listener ejemplo = new E013listener("Ejemplo");
        ejemplo.setVisible(true);
    }
    
}
