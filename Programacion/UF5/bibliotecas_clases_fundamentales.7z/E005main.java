package dev.boca.uf5.bibliotecas_clases_fundamentales;

public class E005main {
    public static void main(String[] args) {
        E005panel ejemplo = new E005panel("Ejemplo increible");
    }
}
