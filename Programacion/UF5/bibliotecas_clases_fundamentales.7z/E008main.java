
package dev.boca.uf5.bibliotecas_clases_fundamentales;

public class E008main {

    public static void main(String[] args) {
        E008botones ejemplo = new E008botones("A por los botones");
    }
    
}
