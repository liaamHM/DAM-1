package dev.boca.uf5.bibliotecas_clases_fundamentales;

public class E011main {
    public static void main(String[] args) {
        E011listeners ejemplo = new E011listeners("Event Listeners");
        ejemplo.setVisible(true);
    }
}
