package dev.boca.uf5.bibliotecas_clases_fundamentales;
public class E012main {
    public static void main(String[] args) {
        E012listener ejemplo = new E012listener("Hola");
        ejemplo.setVisible(true);
    }
    
}
