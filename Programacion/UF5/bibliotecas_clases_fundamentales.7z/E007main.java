package dev.boca.uf5.bibliotecas_clases_fundamentales;

public class E007main {
    public static void main(String[] args) {
        E007etiqueta ejemplo = new E007etiqueta("Ejemplo increible");
    }
}
