package dev.boca.uf5.bibliotecas_clases_fundamentales;

public class E006main {
    public static void main(String[] args) {
        E006etiqueta ejemplo = new E006etiqueta("Ejemplo increible");
    }
}
