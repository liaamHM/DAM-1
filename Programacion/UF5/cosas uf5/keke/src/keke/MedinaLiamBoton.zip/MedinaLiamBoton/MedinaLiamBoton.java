
package keke;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MedinaLiamBoton extends JFrame{
    
    //creo los componentes que voy a utilizar en diferentes clases
    public JPanel panel;
    public JButton boton2;
    public JButton boton1;

    public static void main(String[] args) {
        //inicializo el archivo
        MedinaLiamBoton programa = new MedinaLiamBoton("Aprobar");
        programa.setVisible(true);
    }
    
    private void crearComponentes(){
        //llamo todas las clases donde tengo diferentes componentes o funciones
        crearPanel();
        crearEtiqueta();
        crearBoton();
        eventos();
    }
    
    //Aqui creo el construcotr para obtener el tituo de la ventana, su tamaño, etc.
    public MedinaLiamBoton (String string) throws HeadlessException{
        super(string);
        setVisible(true);
        setSize(500,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        crearComponentes();
    }
    
    //creo el panel de la ventana
    private void crearPanel(){
        panel = new JPanel();
        this.getContentPane().add(panel);
        //le pongo el color que nos pides
        panel.setBackground(Color.cyan);
        //le quito el layout para poder mover los demas componentes con libertad
        panel.setLayout(null);
    }
    //creo una etiqueta par la pregunta inicial
    public void crearEtiqueta(){
        //lo pongo en el centro de la etiqueta
        JLabel etiqueta = new JLabel("¿Aprobaré el M03?", SwingConstants.CENTER);
        //lo añado al panel
        panel.add(etiqueta);
        etiqueta.setBounds(-10, -35, 500, 150);
        //le pongo una fuente (aunque no funciona) y el tamaño de la fuente
        etiqueta.setFont(new Font("ComicSans", Font.PLAIN, 30));
    }
    
    //creo los botones 
    private void crearBoton(){
        //creo los 2 botones y les pongo su titulo
        boton1 = new JButton("¡jamás!");
        boton1.setBounds(30, 200, 150, 40);
        boton2 = new JButton("¡y tanto!");
        boton2.setBounds(300, 100, 150, 40);
        //hago que se puedan pulsar (aunque no les ponga una funcion)
        boton1.setEnabled(true);
        boton2.setEnabled(true);
        //les pongo la fuente, el formato y el tamaño
        boton1.setFont(new Font("calibri", Font.PLAIN, 20));
        boton2.setFont(new Font("calibri", Font.PLAIN, 20));
        //y los añado al panel
        panel.add(boton1);
        panel.add(boton2);
    
}
    //por ultimo hare la funcion donde el boton escape
    private void eventos(){
        //creo el mouse listener
        MouseListener evento = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            //y selecciono la opcion donde se reporduzca la funcion solamente con tocar con el raton
            public void mouseEntered(MouseEvent e) {
                //creo variables aleatorias para que el boton aparezca en cualquier sitio
                int x = (int) (Math.random()*450);
                int y = (int) (Math.random()*450);
                //llamo a los bounds del boton para cambiar su posicion
                boton2.setBounds(x, y, 150, 40);
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        };
        //lo añado
        boton2.addMouseListener(evento);
    }
}
