USE Bar
DECLARE @contadorMaximo INT
SELECT @contadorMaximo = COUNT(*) FROM Articulo
DECLARE @contador INT
SET @contador = 0

WHILE(@contador < @contadorMaximo) BEGIN

	DECLARE @StockActual INT
	DECLARE @StockMinimo INT
	DECLARE @StockMaximo INT
	DECLARE @ArticuloID INT
	SET @ArticuloID = @contador+1

	SELECT @StockActual = StockActual, @StockMinimo = StockMinimo, 	@StockMaximo = StockMaximo 
		FROM Articulo WHERE ID = @ArticuloID

	IF(@StockActual <= @StockMinimo) BEGIN
		DECLARE @pedir INT
		SET @pedir = @StockMaximo - @StockActual

		INSERT INTO LineaPedido(ArticuloID, Unidades)
			VALUES (@ArticuloID, @pedir)
	END
	SET @contador = @contador + 1
END

SELECT * FROM LineaPedido