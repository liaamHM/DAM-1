CREATE TABLE ArticulosProvedores(
	ID INT IDENTITY (1,1) PRIMARY KEY NOT NULL,
	NombreArticulo nvarchar(50) NOT NULL,
	ProveedorID INT FOREIGN KEY REFERENCES Proveedores(ID),
	PrecioUnidad DECIMAL(29, 2)
)

CREATE TABLE LineaPedido(
	ID INT IDENTITY (1,1) PRIMARY KEY NOT NULL,
	ArticulosProveedoresID int FOREIGN KEY REFERENCES ArticulosProvedores(ID),
	Unidades INT 
)

CREATE TABLE Proveedores (
	ID INT IDENTITY (1,1) PRIMARY KEY NOT NULL,
	Nombre nvarchar(50)
)

ALTER TABLE Articulo
	ADD ProveedorID INT FOREIGN KEY REFERENCES 

ALTER TABLE Articulo
	ADD StockActual INT

ALTER TABLE Articulo
	ADD StockMinimo INT

ALTER TABLE Articulo
	ADD StockMaximo INT