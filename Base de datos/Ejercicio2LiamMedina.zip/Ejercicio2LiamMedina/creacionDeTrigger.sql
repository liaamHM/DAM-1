
CREATE TRIGGER [dbo].[tgrActualizarStocks]
   ON  [dbo].[Linea]
   AFTER Insert
AS 
BEGIN
	DECLARE @unidades INT
	DECLARE @ArticuloID INT

	SELECT @ArticuloID = ArticuloId, @unidades = Unidades FROM inserted

	if((select stockactual from Articulo where Id = @ArticuloID) > @unidades)
	BEGIN
		UPDATE Articulo
			SET StockActual = StockActual - @Unidades
			WHERE Id = @ArticuloID
	END
END