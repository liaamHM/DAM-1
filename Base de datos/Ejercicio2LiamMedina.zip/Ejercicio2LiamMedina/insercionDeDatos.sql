-- INSERTANDO LOS VALORES DE TIPODEIVA
INSERT INTO TipoIva(Nombre, PorcentajeIva) VALUES ('Normal', 21)
INSERT INTO TipoIva(Nombre, PorcentajeIva) VALUES ('Reducido', 10)

-- INSERTANDO LOS VALORES DEL PROVEEDOR
INSERT INTO Proveedores(Nombre)
	VALUES ('Proveedor 1')

INSERT INTO Proveedores(Nombre)
	VALUES ('Proveedor 2')

INSERT INTO Proveedores(Nombre)
	VALUES ('Proveedor 3')

-- INSERTANDO LOS VALORES DE ARTICULO
    INSERT INTO Articulo(Nombre, TipoIvaId, PrecioFinal, Ventas, ProveedorID, StockActual, StockMinimo, StockMaximo)
	VALUES ('Cafe', 1, 1.40, 0)
INSERT INTO Article(Nombre, TipoIvaId, PrecioFinal, Ventas, ProveedorID, StockActual, StockMinimo, StockMaximo)
	VALUES ('Cafe con leche', 1, 1.70, 0)
INSERT INTO Article(Nombre, TipoIvaId, PrecioFinal, Ventas, ProveedorID, StockActual, StockMinimo, StockMaximo)
	VALUES ('Bocata', 1, 3, 0)
INSERT INTO Article(Nombre, TipoIvaId, PrecioFinal, Ventas, ProveedorID, StockActual, StockMinimo, StockMaximo)
	VALUES ('Croissant', 2, 2.20, 0)
INSERT INTO Article(Nombre, TipoIvaId, PrecioFinal, Ventas, ProveedorID, StockActual, StockMinimo, StockMaximo)
	VALUES ('Ensalada se pasta', 1,4.50, 0)

-- INSERTAMOS LOS DATOS DE MESA
INSERT INTO Mesa(Nombre)
	VALUES ('Mesa 1')
INSERT INTO Mesa(Nombre)
	VALUES ('Mesa 2')
INSERT INTO Mesa(Nombre)
	VALUES ('Mesa 3')

-- INSERTAMOS LOS DATOS DE TICKET
INSERT INTO Ticket(MesaId)
	VALUES (1)
INSERT INTO Ticket(MesaId)
	VALUES (2)
INSERT INTO Ticket(MesaId)
	VALUES (3)

-- INSERTAMOS LOS DATOS DE LINEA
INSERT INTO Linea(TicketId, ArticuloId, Nombre, TipoIvaId, PrecioFinal, Unidades)
	VALUES (1, 1, 'h', 1, 1, 3)
INSERT INTO Linea(TicketId, ArticuloId, Nombre, TipoIvaId, PrecioFinal, Unidades)
	VALUES (2, 3, 'h', 1, 1, 4)
INSERT INTO Linea(TicketId, ArticuloId, Nombre, TipoIvaId, PrecioFinal, Unidades)
	VALUES (1, 4, 'h', 1, 1, 1)
INSERT INTO Linea(TicketId, ArticuloId, Nombre, TipoIvaId, PrecioFinal, Unidades)
	VALUES (3, 1, 'h', 1, 1, 1)
INSERT INTO Linea(TicketId, ArticuloId, Nombre, TipoIvaId, PrecioFinal, Unidades)
	VALUES (3, 2, 'h', 1, 1, 1)

